"""
This _just_ exists in case you want to download this all at once and use these Fundamentals like a package
"""