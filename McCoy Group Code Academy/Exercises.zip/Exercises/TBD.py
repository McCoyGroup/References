# THIS IS A PLACEHOLDER: AS WE ADD THINGS WE'LL FILL THIS OUT
"""
Goal: ...
Fundamentals: ... (Comma-separated list)
Related Exercises: ... (Comma-separated list)
"""

## Imports: put all import statments here

## Exports: put all the names things we might want to use in other scripts here

__all__ = [
]

## Objects: put all the classes we're defining here
...

## Functions: put all the functions we're defining here
...

## Run Script: put the script we'd want to run from the command line here

if __name__ == '__main__':
    ...